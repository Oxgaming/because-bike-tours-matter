function data()
  return {  
	info = {
		minorVersion = 1,
		severityAdd = "NONE",
		severityRemove = "WARNING", 
		name = _("Lokhallen"),
		description = _("Kleine Lok-hallen/schuppen als Assets."),
		authors = {
			{
				name = 'OX-Gaming',
				role = 'CREATOR',
				text = 'Modell',
				tfnetId = 63467,
			},
		},
		tags = { "Europe", "Train", "Germany", "Asset", "Track Asset", },
		dependencies = {},
	},  
  }
end
