function data()
  return {  
	info = {
		minorVersion = 1,
		severityAdd = "NONE",
		severityRemove = "WARNING", 
		name = _("Rheinbahnschilder"),
		description = _("EN: Diverse assets of the Rheinbahn/Bahnen Monheim to place. In terms of better appearance, I would use the invisible stops. Have fun! DE: Diverse Assets der Rheinbahn/Bahnen Monheim zum platzieren. Ich würde im Bezug auf bessere Optik, die unsichtbaren Haltestellen benutzen. Viel Spaß"),
		authors = {
			{
				name = 'OX-Gaming, Siri',
				role = 'CREATOR',
				text = 'Modell',
				tfnetId = 63467,
			},
		},
		tags = { "Europe", "Bus", "Street Asset", },
		dependencies = {},
	},  
  }
end
